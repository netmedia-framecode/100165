<header class="header_section">
  <div class="header_bottom">
    <div class="container-fluid">
      <nav class="navbar navbar-expand-lg custom_nav-container">
        <a class="navbar-brand" href="index.html">
          <img src="<?= $baseURL ?>assets/img/logo.png" style="width: 65px;" alt="">
        </a>
        </a>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class=""> </span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="./">Beranda</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="tentang">Tentang</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="prediksi">Prediksi</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="laporan">Laporan</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="kontak">Kontak</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="auth/"><i class="bi bi-box-arrow-in-right"></i> Login</a>
            </li>
          </ul>
        </div>
      </nav>
    </div>
  </div>
</header>