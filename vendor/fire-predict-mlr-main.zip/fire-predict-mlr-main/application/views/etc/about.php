<br>
<div>
    Aplikasi web prediksi area kebakaran hutan v1.0 dengan metode <i>multiple linear regression</i> by YukCoding Media.
</div>