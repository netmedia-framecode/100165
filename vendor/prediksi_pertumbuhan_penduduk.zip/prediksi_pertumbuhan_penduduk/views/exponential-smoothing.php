<?php require_once("../controller/script.php");
$_SESSION["project_prediksi_pertumbuhan_penduduk"]["name_page"] = "Exponential Smoothing";
require_once("../templates/views_top.php"); ?>

<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><?= $_SESSION["project_prediksi_pertumbuhan_penduduk"]["name_page"] ?></h1>
  </div>

  <!-- Mulai buatlah lembar kerja anda disini! -->




  <div class="modal-content">
    <div class="modal-header border-bottom-0 shadow">
      <h5 class="modal-title" id="tambahLabel"> Prediksi</h5>
      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>

    <form action="" method="post">
      <div class="modal-body">
        <div class="form-group">
          <label for="uji_periode">Periode</label>
          <input type="number" name="uji_periode" class="form-control" id="uji_periode" aria-describedby="emailHelp" minlength="3" required>
        </div>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label for="nilai_alpha">Nilai Alpha</label>
          <input type="number" name="nilai_alpha" step="0.1" min="0.1" max="1" class="form-control" id="nilai_alpha" aria-describedby="emailHelp" required>
        </div>
      </div>
      <div class="modal-body">
        <h5 class="modal-title" id="tambahLabel"> <b>Variabel</b><br><br> </h5>

        <div class="form-group">
          <label for="variabel_dependen">Variabel Dependen</label>
          <select name="variabel_dependen" class="form-control" id="variabel_dependen" required>
            <option value="" selected>Pilih Variabel</option>
            <?php foreach ($views_variabel as $data_select_variabel) { ?>
              <option value="<?= $data_select_variabel['id_variabel'] ?>"><?= $data_select_variabel['nama_variabel'] ?></option>
            <?php } ?>
          </select>
        </div>

      </div>

      <div class="modal-footer justify-content-center border-top-0">
        <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Batal</button>
        <button type="submit" name="uji_prediksi" class="btn btn-primary btn-sm">Tambah</button>
      </div>
    </form>
  </div>


  <?php
  // Proses form jika ada data yang dikirim
  if (isset($_POST['uji_prediksi'])) {
    // Ambil data dari formulir
    $nilai_alpha = $_POST['nilai_alpha'];
    $uji_periode = $_POST['uji_periode'];
    // Simpan NAMA variabel independen yang dipilih
    $variabel_dependen_id = $_POST['variabel_dependen']; // ID variabel independen
    $variabel_dependen = ''; // Inisialisasi nama variabel independen


    // Ambil nama variabel dependen

    $jumlah_data_dependen = 0;
    foreach ($views_variabel as $data_select_variabel) {
      if ($data_select_variabel['id_variabel'] == $variabel_dependen_id) {
        $variabel_dependen = $data_select_variabel['nama_variabel'];
        // Hitung jumlah data untuk variabel dependen
        foreach ($views_jumlah as $data) {
          if ($data['nama_variabel'] == $variabel_dependen) {
            $jumlah_data_dependen += $data['jumlah'];
          }
        }
        break;
      }
    }


    // Inisialisasi array untuk menyimpan entri unik variabel independen dan dependen

    $uniques_dependen = [];


    // Hitung banyaknya entri unik untuk variabel dependen
    foreach ($views_jumlah as $data) {
      if ($data['nama_variabel'] == $variabel_dependen) {
        if (!in_array($data['periode'], $uniques_dependen)) {
          $uniques_dependen[] = $data['periode'];
        }
      }
    }

    // Hitung jumlah entri unik untuk masing-masing variabel independen dan dependen

    $banyaknya_data_dependen = count($uniques_dependen);

    //hitung koefisien regresi

    $sum_y = $jumlah_data_dependen / $banyaknya_data_dependen;
  }


  ?>




  <div class="card shadow mb-4 border-0">
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered text-dark" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>Periode</th>
              <th>Nilai Alpha</th>

              <th>Variabel Dependen</th>

            </tr>
          </thead>

          <tbody>

            <tr>
              <td><?php echo isset($uji_periode) ? $uji_periode : ''; ?></td>
              <td><?php echo isset($nilai_alpha) ? $nilai_alpha : ''; ?></td>

              <td><?php echo isset($variabel_dependen) ? $variabel_dependen : ''; ?></td>


            </tr>

          </tbody>
        </table>
      </div>
    </div>
  </div>

  <?php

  $select_dependen = "SELECT dataset.*, data_periode.periode, data_variabel.nama_variabel
FROM dataset 
JOIN data_periode ON dataset.id_periode = data_periode.id_periode 
JOIN data_variabel ON dataset.id_variabel = data_variabel.id_variabel 
WHERE data_variabel.nama_variabel = '$variabel_dependen' 
ORDER BY dataset.id_periode";



  $views_dependen = mysqli_query($conn, $select_dependen);

  ?>

  <div class="card shadow mb-4 border-0">
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered text-dark" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th class="text-center">Periode</th>
              <th class="text-center">Nama Variabel</th>
              <th class="text-center">Jumlah</th>

            </tr>
          </thead>
          <tfoot>
            <tr>
              <th class="text-center">Periode</th>
              <th class="text-center">Nama Variabel</th>
              <th class="text-center">Jumlah</th>

            </tr>
          </tfoot>
          <tbody>
            <?php foreach ($views_dependen as $data) { ?>
              <tr>
                <td><?= $data['periode'] ?></td>
                <td><?= $data['nama_variabel'] ?></td>
                <td><?= $data['jumlah'] ?></td>

              </tr>
            <?php } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>



  <div class="card shadow mb-4 border-0">
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered text-dark" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th class="text-center">Periode</th>
              <th class="text-center">Ramalan</th>
            </tr>
          </thead>
          <tfoot>
            <tr>
              <th class="text-center">Periode</th>
              <th class="text-center">Ramalan</th>
            </tr>
          </tfoot>
          <tbody>
            <?php
            // Inisialisasi array untuk menyimpan nilai aktual dan nilai ramalan
            $actual_values = array();
            $forecast_values = array();

            // Lakukan single exponential smoothing untuk prediksi
            $alpha = $nilai_alpha; // Nilai alpha dari input pengguna

            // Asumsikan nilai awal sama dengan nilai terakhir dari data dependen
            $prev_forecast = 0; // Nilai ramalan awal diatur menjadi 0

            // Tandai apakah ramalan pertama sudah dilakukan
            $first_forecast_done = false;

            // Inisialisasi total MAD, MSE, dan MAPE
            $total_mad = 0;
            $total_mse = 0;
            $total_mape = 0;

            // Hitung smoothing untuk setiap periode
            foreach ($views_dependen as $key => $data) {
              if ($data['nama_variabel'] == $variabel_dependen) {
                // Set ramalan tahun 2015 dengan nilai aktual jika ini adalah data pertama
                if (!$first_forecast_done) {
                  $prev_forecast = $data['jumlah'];
                  $first_forecast_done = true;

                  // Tampilkan hasil peramalan dalam baris tabel untuk tahun 2015
                  echo "<tr>";
                  echo "<td>{$data['periode']}</td>";
                  echo "<td>$prev_forecast</td>";
                  echo "</tr>";

                  // Simpan nilai aktual dan nilai ramalan
                  $actual_values[] = $data['jumlah'];
                  $forecast_values[] = $prev_forecast;
                } else {
                  // Hitung ramalan menggunakan rumus eksponensial smoothing
                  $forecast = $alpha * $data['jumlah'] + (1 - $alpha) * $prev_forecast;

                  // Simpan hasil ramalan untuk digunakan di periode berikutnya
                  $prev_forecast = $forecast;

                  // Hitung MAD untuk periode saat ini
                  $mad = abs($data['jumlah'] - $forecast);

                  // Hitung MSE untuk periode saat ini
                  $mse = pow($data['jumlah'] - $forecast, 2);

                  // Hitung MAPE untuk periode saat ini
                  $mape = abs(($data['jumlah'] - $forecast) / $data['jumlah']) * 100;

                  // Tambahkan MAD, MSE, dan MAPE ke total
                  $total_mad += $mad;
                  $total_mse += $mse;
                  $total_mape += $mape;

                  // Tampilkan hasil peramalan dalam baris tabel
                  echo "<tr>";
                  echo "<td>{$data['periode']}</td>";
                  echo "<td>$forecast</td>";
                  echo "<td>$mad</td>"; // MAD
                  echo "<td>$mse</td>"; // MSE
                  echo "<td>$mape%</td>"; // MAPE
                  echo "</tr>";

                  // Simpan nilai aktual dan nilai ramalan
                  $actual_values[] = $data['jumlah'];
                  $forecast_values[] = $forecast;
                }
              }
            }

            // Hitung rata-rata MAD, MSE, dan MAPE
            $mean_mad = $total_mad / count($actual_values);
            $mean_mse = $total_mse / count($actual_values);
            $mean_mape = $total_mape / count($actual_values);

            // Tampilkan hasil rata-rata MAD, MSE, dan MAPE
            echo "<tr>";
            echo "<td><b>Rata-rata MAD</b></td>";

            echo "<td>$mean_mad</td>";
            echo "<td><b>Rata-rata MSE</b></td>";
            echo "<td>$mean_mse</td>";
            echo "<td><b>Rata-rata MAPE</b></td>";
            echo "<td>$mean_mape%</td>";
            echo "</tr>";

            ?>


          </tbody>
        </table>
      </div>
    </div>
  </div>





  <?php


  // Melakukan prediksi

  $F_prediksi = $alpha * $prev_forecast + (1 - $alpha) * $prev_forecast;

  // Tampilkan hasil prediksi
  echo "<div class='card shadow mb-4 border-0'>";
  echo "    <div class='card-body'>";
  echo "        <h4 class='text-center'>Hasil Prediksi</h4>";
  echo "        <p class='text-center'>Jumlah Penduduk berdasarkan $uji_periode adalah: $F_prediksi</p>";
  echo "    </div>";
  echo "</div>";

  ?>



</div>
<!-- /.container-fluid -->

<?php require_once("../templates/views_bottom.php") ?>