<?php require_once("../controller/script.php");
$_SESSION["project_prediksi_pertumbuhan_penduduk"]["name_page"] = "Regression Linear";
require_once("../templates/views_top.php"); ?>

<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><?= $_SESSION["project_prediksi_pertumbuhan_penduduk"]["name_page"] ?></h1>
  </div>

  <!-- Mulai buatlah lembar kerja anda disini! -->
  <div class="modal-content">
    <div class="modal-header border-bottom-0 shadow">
      <h5 class="modal-title" id="tambahLabel"> Prediksi</h5>
      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>

    <form action="" method="post">
      <div class="modal-body">
        <div class="form-group">
          <label for="uji_periode">Periode</label>
          <input type="text" name="uji_periode" class="form-control" id="uji_periode" aria-describedby="emailHelp" minlength="3" required>
        </div>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label for="D_migrasi">Data Migrasi</label>
          <input type="text" name="D_migrasi" class="form-control" id="D_migrasi" aria-describedby="emailHelp" required>
        </div>
      </div>
      <div class="modal-body">
        <h5 class="modal-title" id="tambahLabel"> <b>Variabel</b><br><br> </h5>
        <div class="form-group">
          <label for="variabel_independen">Variabel Independen</label>
          <select name="variabel_independen" class="form-control" id="variabel_independen" required>
            <option value="" selected>Pilih Variabel</option>
            <?php foreach ($views_variabel as $data_select_variabel) { ?>
              <option value="<?= $data_select_variabel['id_variabel'] ?>"><?= $data_select_variabel['nama_variabel'] ?></option>
            <?php } ?>
          </select>
        </div>
        <div class="form-group">
          <label for="variabel_dependen">Variabel Dependen</label>
          <select name="variabel_dependen" class="form-control" id="variabel_dependen" required>
            <option value="" selected>Pilih Variabel</option>
            <?php foreach ($views_variabel as $data_select_variabel) { ?>
              <option value="<?= $data_select_variabel['id_variabel'] ?>"><?= $data_select_variabel['nama_variabel'] ?></option>
            <?php } ?>
          </select>
        </div>

      </div>

      <div class="modal-footer justify-content-center border-top-0">
        <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Batal</button>
        <button type="submit" name="uji_prediksi" class="btn btn-primary btn-sm">Tambah</button>
      </div>
    </form>
  </div>


  <?php
  // Proses form jika ada data yang dikirim
  if (isset($_POST['uji_prediksi'])) {
    $D_migrasi = $_POST['D_migrasi'];
    $uji_periode = $_POST['uji_periode'];
    $variabel_dependen_id = $_POST['variabel_dependen'];
    $variabel_dependen = '';
    $variabel_independen_id = $_POST['variabel_independen'];
    $variabel_independen = '';

    $jumlah_data_independen = 0;
    foreach ($views_variabel as $data_select_variabel) {
      if ($data_select_variabel['id_variabel'] == $variabel_independen_id) {
        $variabel_independen = $data_select_variabel['nama_variabel'];
        // Hitung jumlah data untuk variabel independen
        foreach ($views_jumlah as $data) {
          if ($data['nama_variabel'] == $variabel_independen) {
            $jumlah_data_independen += $data['jumlah'];
          }
        }
        break;
      }
    }

    $jumlah_data_dependen = 0;
    foreach ($views_variabel as $data_select_variabel) {
      if ($data_select_variabel['id_variabel'] == $variabel_dependen_id) {
        $variabel_dependen = $data_select_variabel['nama_variabel'];
        // Hitung jumlah data untuk variabel dependen
        foreach ($views_jumlah as $data) {
          if ($data['nama_variabel'] == $variabel_dependen) {
            $jumlah_data_dependen += $data['jumlah'];
          }
        }
        break;
      }
    }

    $uniques_independen = [];
    $uniques_dependen = [];

    foreach ($views_jumlah as $data) {
      if ($data['nama_variabel'] == $variabel_independen) {
        if (!in_array($data['periode'], $uniques_independen)) {
          $uniques_independen[] = $data['periode'];
        }
      }
    }

    foreach ($views_jumlah as $data) {
      if ($data['nama_variabel'] == $variabel_dependen) {
        if (!in_array($data['periode'], $uniques_dependen)) {
          $uniques_dependen[] = $data['periode'];
        }
      }
    }

    $banyaknya_data_independen = count($uniques_independen);
    $banyaknya_data_dependen = count($uniques_dependen);

    $sum_x = $jumlah_data_independen / $banyaknya_data_independen;
    $sum_y = $jumlah_data_dependen / $banyaknya_data_dependen;

    $mean_x = $jumlah_data_independen / $banyaknya_data_independen;
    $mean_y = $jumlah_data_dependen / $banyaknya_data_dependen;

    $nilai_independen = array();
    $nilai_dependen = array();
    $denominator = 0;
    $numerator = 0;

    foreach ($views_jumlah as $data) {
      if ($data['nama_variabel'] == $variabel_independen) {
        $nilai_independen[] = $data['jumlah'];
      } elseif ($data['nama_variabel'] == $variabel_dependen) {
        $nilai_dependen[] = $data['jumlah'];
      }
    }
  }

  ?>

  <div class="card shadow mb-4 border-0">
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered text-dark" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>Periode</th>
              <th>Jumlah Migrasi</th>
              <th>Variabel Independen</th>
              <th>Variabel Dependen</th>

            </tr>
          </thead>

          <tbody>

            <tr>
              <td><?php echo isset($uji_periode) ? $uji_periode : ''; ?></td>
              <td><?php echo isset($D_migrasi) ? $D_migrasi : ''; ?></td>
              <td><?php echo isset($variabel_independen) ? $variabel_independen : ''; ?></td>
              <td><?php echo isset($variabel_dependen) ? $variabel_dependen : ''; ?></td>


            </tr>

          </tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="card shadow mb-4 border-0">
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered text-dark" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th class="text-center">Periode</th>
              <th class="text-center">Nama Variabel</th>
              <th class="text-center">Jumlah</th>

            </tr>
          </thead>
          <tfoot>
            <tr>
              <th class="text-center">Periode</th>
              <th class="text-center">Nama Variabel</th>
              <th class="text-center">Jumlah</th>

            </tr>
          </tfoot>
          <tbody>
            <?php foreach ($views_jumlah as $data) { ?>
              <tr>
                <td><?= $data['periode'] ?></td>
                <td><?= $data['nama_variabel'] ?></td>
                <td><?= $data['jumlah'] ?></td>

              </tr>
            <?php } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>


  <!-- Tampilkan hasil perhitungan jumlah data -->
  <div class="card shadow mb-4 border-0">
    <div class="card-body">
      <h4 class="text-center">Jumlah Data untuk Uji Prediksi</h4>
      <p class="text-center">Variabel Independen (<?php if (isset($variabel_independen)) {
                                                    echo $variabel_independen;
                                                  } else {
                                                    echo "-";
                                                  }  ?>): <?php if (isset($jumlah_data_independen)) {
                                                            echo $jumlah_data_independen;
                                                          } else {
                                                            echo "-";
                                                          } ?></p>
      <p class="text-center">Variabel Dependen (<?php if (isset($variabel_dependen)) {
                                                  echo $variabel_dependen;
                                                } else {
                                                  echo "-";
                                                } ?>): <?php if (isset($jumlah_data_dependen)) {
                                                          echo $jumlah_data_dependen;
                                                        } else {
                                                          echo "-";
                                                        } ?></p>
    </div>
  </div>

  <div class="card shadow mb-4 border-0">
    <div class="card-body">
      <h4 class="text-center">Rumus Regresi Linear</h4>
      <p class="text-center">Y = b<sub>0</sub> + b<sub>1</sub>X</p>
      <p class="text-center">Dimana:</p>
      <ul>
        <li><strong>Y</strong> adalah variabel dependen (output).</li>
        <li><strong>X</strong> adalah variabel independen (input).</li>
        <li><strong>b<sub>0</sub></strong> adalah intersep (nilai Y ketika X = 0).</li>
        <li><strong>b<sub>1</sub></strong> adalah koefisien regresi (perubahan Y untuk setiap perubahan satu unit X).</li>
      </ul>

      <h4 class="text-center">Perhitungan b0 dan b1</h4>
      <p class="text-center">Untuk menghitung b<sub>0</sub> dan b<sub>1</sub>, Anda dapat menggunakan rumus berikut:</p>
      <ul>
        <li><strong>b<sub>1</sub> = Σ((X - X̄)(Y - Ȳ)) / Σ((X - X̄)<sup>2</sup>)</strong></li>
        <li><strong>b<sub>0</sub> = Ȳ - b<sub>1</sub>X̄</strong></li>
        <li><strong>Σ</strong> adalah simbol sigma yang menunjukkan penjumlahan.</li>
        <li><strong>X̄</strong> adalah rata-rata dari variabel independen (X).</li>
        <li><strong>Ȳ</strong> adalah rata-rata dari variabel dependen (Y).</li>
      </ul>
    </div>
  </div>

  <div class="card shadow mb-4 border-0">
    <div class="card-body">
      <h4 class="text-center">Data Hasil Perhitungan</h4>
      <div class="table-responsive">
        <table class="table table-bordered text-dark" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>Nilai Independen</th>
              <th>Nilai Dependen</th>
              <th><strong><sub></sub>X - X̄</strong></th>
              <th><strong><sub></sub>Y - Ȳ</strong></th>
            </tr>
          </thead>
          <tbody>
            <?php

            if (isset($nilai_independen)) {
              // Loop untuk menampilkan hasil perhitungan
              for ($i = 0; $i < count($nilai_independen); $i++) {
                echo "<tr>";
                echo "<td>" . $nilai_independen[$i] . "</td>";
                echo "<td>" . $nilai_dependen[$i] . "</td>";

                // Hitung perbedaan X dan Y
                $diff_x = $nilai_independen[$i] - $mean_x;
                $diff_y = $nilai_dependen[$i] - $mean_y;

                echo "<td>" . $diff_x . "</td>";
                echo "<td>" . $diff_y . "</td>";
                echo "</tr>";

                // Hitung akumulasi denominator dan numerator
                $denominator += pow($diff_x, 2);
                $numerator += $diff_x * $diff_y;
              }
            }
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <?php

  // Hitung rata-rata independen dan dependen
  $mean_x = array_sum($nilai_independen) / count($nilai_independen);
  $mean_y = array_sum($nilai_dependen) / count($nilai_dependen);

  // Hitung korelasi antara dua variabel
  $denominator = 0;
  $numerator = 0;
  for ($i = 0; $i < count($nilai_independen); $i++) {
    $diff_x = $nilai_independen[$i] - $mean_x;
    $diff_y = $nilai_dependen[$i] - $mean_y;

    $denominator += pow($diff_x, 2);
    $numerator += $diff_x * $diff_y;
  }

  // Hitung korelasi (koefisien kovarians)
  $b1 = $numerator / $denominator;
  $b0 = $mean_y - $b1 * $mean_x;

  // Output hasil perhitungan
  echo "<div class='card shadow mb-4 border-0'>";
  echo "    <div class='card-body'>";
  echo "        <h4 class='text-center'>Koefisien Regresi (b1)</h4>";
  echo "        <p class='text-center'>" . $b1 . "</p>";
  echo "        <h4 class='text-center'>Intersep (b0)</h4>";
  echo "        <p class='text-center'>" . $b0 . "</p>";
  echo "    </div>";
  echo "</div>";

  // Melakukan prediksi

  $nilai_dependen_prediksi = $b0 + $b1 * $D_migrasi;

  // Tampilkan hasil prediksi
  echo "<div class='card shadow mb-4 border-0'>";
  echo "    <div class='card-body'>";
  echo "        <h4 class='text-center'>Hasil Prediksi</h4>";
  echo "        <p class='text-center'>Jumlah Penduduk berdasarkan data migrasi $D_migrasi adalah: $nilai_dependen_prediksi</p>";
  echo "    </div>";
  echo "</div>";

  ?>



</div>
<!-- /.container-fluid -->

<?php require_once("../templates/views_bottom.php") ?>